
//created a local storage function that will store the movies in the local storage when the user clicks the watch later button for each movie
export function storeMovie(movie){
    let movies;
    document.querySelector('.watchlaterBtn').addEventListener('click', () => {
        //if there is no movies in the local storage, create a new array to store the movies
        if(localStorage.getItem('movieList') === null){
            movies = [];
        }
        //if there are movies in the local storage, get the movies from the local storage
        else{
            movies = JSON.parse(localStorage.getItem('movieList'));
        }
        //push the movie to the movies array
        movies.push(movie);
        //store the movies in the local storage
        localStorage.setItem('movieList', JSON.stringify(movies));
        //alert the user that the movie has been added to the watch later list
        alert('Movie added to watch later list');

    }
    )
}


//created a function when the user clicks on the watchlater they will be redirected to the watch later page
export function watchLaterPage(){
    document.querySelector('.watchlater').addEventListener('click', () => {
        window.location.href = 'watchLater.html';
        //display the movies from the local storage
        displayWatchLater();
    })
}

//function when page loads to display the movies from the local storage
export function displayWatchLater(){
   //display the movies in the storeMovie function
    const watchLater = JSON.parse(localStorage.getItem('movieList'));
    watchLater.forEach(movie => {
        const {title, imageurl, imdbrating, synopsis} = movie;
        const movieOne = document.createElement('div');
        movieOne.classList.add('movie');
        movieOne.innerHTML = `<button class="watchlaterBtn"><i class="fa fa-heart fa-lg"></i></button>
        <img src="${imageurl? imageurl:"noImage.png"  }" alt="${title}">
        <div class="movie-info">
        <h3>${title}</h3>
        <span class="${getColor(imdbrating)}">${imdbrating}</span>
    </div>

    <div class="overview">
        <h3>synopsis</h3>
        ${synopsis}
    </div>`

    main.appendChild(movieOne);
    })
}

function getColor(vote){
    if(vote >= 4){
        return 'green';
    }else if(vote >= 2 && vote < 4){
        return 'orange';
    }else{
        return 'red';
    }
}