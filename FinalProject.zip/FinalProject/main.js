import { API } from "./Api.js";

API();
